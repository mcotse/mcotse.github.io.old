import React from "react";


export default class Footer extends React.Component {
  render() {
    return (
      <footer>
        <br></br>
        <a href="https://github.com/mcotse" class="fa fa-lg fa-github"></a><i> </i>
        <a href="http://matthewtse.xyz" class="fa fa-lg fa-globe"></a>
        <p>Matthew Tse 2016</p>
    </footer>
    );
  }
}
